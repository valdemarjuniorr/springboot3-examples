package br.com.valdemajr.testcontainer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestcontainerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

package br.com.valdemajr.testcontainer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcontainerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcontainerExampleApplication.class, args);
	}

}
